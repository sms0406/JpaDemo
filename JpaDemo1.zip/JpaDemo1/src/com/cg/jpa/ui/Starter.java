package com.cg.jpa.ui;

import java.time.LocalDate;

import com.cg.jpa.dao.EmployeeDAO;
import com.cg.jpa.dao.EmployeeJpqlDao;
import com.cg.jpa.model.Employee;

public class Starter {
	public static void main(String[] args) {
		/*Employee emp = new Employee();
		emp.setCity("chennai");
		//emp.setEmpId(6002);
		emp.setEmpName("john");
		emp.setSalary(45000);
		emp.setDateOfJoining(LocalDate.now());
		new EmployeeDAO().addEmployee(emp);*/
		//new EmployeeDAO().getEmployee();
		//new EmployeeDAO().updateEmployee();
		//new EmployeeDAO().deleteEmployee();
		new EmployeeJpqlDao().getEmployees();
		System.out.println("prog ends");
	}

}
