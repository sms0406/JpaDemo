package com.cg.jpa.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.jpa.model.Employee;

public class EmployeeDAO {

	public void addEmployee(Employee e) {
		EntityManagerFactory emf=null;
		EntityManager em=null;
		try {
			//jpa logic to perform insert operation
			emf = Persistence.createEntityManagerFactory("JpaDemo1");
			em = emf.createEntityManager();
			em.getTransaction().begin();
			em.persist(e);
			em.getTransaction().commit();
		}catch(Exception ex) {
			ex.printStackTrace();
		}
		finally {
			if(em!=null && emf!=null) {
				em.close();
				emf.close();

			}
		}





	}


	public void getEmployee() {

		EntityManagerFactory emf=null;
		EntityManager em=null;
		try {
			//jpa logic to perform insert operation
			emf = Persistence.createEntityManagerFactory("JpaDemo1");
			em = emf.createEntityManager();

			Employee emp= em.find(Employee.class, 101);
			if(emp!=null) {
				System.out.println(emp.getCity());
				System.out.println(emp.getEmpName());}
			else {
				System.out.println("employee details not found for the given id"); 

			}

		}catch(Exception ex) {
			ex.printStackTrace();
		}
		finally {
			if(em!=null && emf!=null) {
				em.close();
				emf.close();

			}
		}

	}
	public void updateEmployee() {


		EntityManagerFactory emf=null;
		EntityManager em=null;
		try {
			//jpa logic to perform insert operation
			emf = Persistence.createEntityManagerFactory("JpaDemo1");
			em = emf.createEntityManager();

			Employee emp= em.find(Employee.class, 2003);
			if(emp!=null) {
				em.getTransaction().begin();

				emp.setEmpName("newname");
				emp.setSalary(55000);
				em.getTransaction().commit();

			}else {
				System.out.println("employee details not found for the given id"); 

			}

		}catch(Exception ex) {
			ex.printStackTrace();
		}
		finally {
			if(em!=null && emf!=null) {
				em.close();
				emf.close();

			}
		}


	}
	
	public void deleteEmployee() {
		
		EntityManagerFactory emf=null;
		EntityManager em=null;
		try {
		//jpa logic to perform insert operation
			emf = Persistence.createEntityManagerFactory("JpaDemo1");
		 em = emf.createEntityManager();
		 
		Employee emp= em.find(Employee.class, 2003);
		if(emp!=null) {
			
			em.getTransaction().begin();
			em.remove(emp);
			em.getTransaction().commit();
			
		}
		else {
			System.out.println("employee details not found for the given id"); 
			
		}
		
		}catch(Exception ex) {
			ex.printStackTrace();
		}
		finally {
			if(em!=null && emf!=null) {
				em.close();
				emf.close();
				
			}
		}
		
	}

}
