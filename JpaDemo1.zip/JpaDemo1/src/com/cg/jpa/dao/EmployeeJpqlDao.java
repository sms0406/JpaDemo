package com.cg.jpa.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import com.cg.jpa.model.Employee;

public class EmployeeJpqlDao {
	
	public void getEmployees() {
		EntityManagerFactory emf=null;
		EntityManager em=null;
		try {
			//jpa logic to perform insert operation
			emf = Persistence.createEntityManagerFactory("JpaDemo1");
			em = emf.createEntityManager();
			int salary=50000;
			/*Query q = em.createQuery("select e from Employee e where e.salary > ?1");
			q.setParameter(1, 50000);*/
			/*TypedQuery<Employee>q = em.createQuery("select e from Employee e where e.salary > :sal", Employee.class);
			q.setParameter("sal", 40000);
			
			
			List<Employee> list= q.getResultList();
			for (Employee employee : list) {
				System.out.println(employee.getEmpId());
				System.out.println(employee.getEmpName());
			}*/
/*//			Query q2 = em.createQuery("select e.empName,e.empId from Employee e where e.salary > :sal");
//			q2.setParameter("sal", 46000);
//			List<Object[]>nameidlist = q2.getResultList();
//			for (Object[] objects : nameidlist) {
//				System.out.println(objects[0]); 
//				System.out.println(objects[1]);
//				
//			} 
//			
//			Query q3 = em.createQuery("select count(*) from Employee e");
//			Long l=(Long)q3.getSingleResult();
//			System.out.println("no of rec "+l);
//			
*/			em.getTransaction().begin();
			Query q4 = em.createQuery("update Employee set salary=salary+100");
			int rows=q4.executeUpdate();
			em.getTransaction().commit();
			System.out.println("rows updated are "+rows);
			
		}catch(Exception ex) {
			ex.printStackTrace();
		}
		finally {
			if(em!=null && emf!=null) {
				em.close();
				emf.close();

			}
		}
	}

}
