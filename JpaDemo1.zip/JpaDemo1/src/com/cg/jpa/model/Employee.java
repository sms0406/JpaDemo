package com.cg.jpa.model;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;

//sequence , auto, identity and table

@Entity
@Table(name="employee")
public class Employee {
	@Id	
	@Column(name="empid")
	/*@SequenceGenerator(name="genname", sequenceName="myseq",allocationSize=1)
	@GeneratedValue(generator="genname", strategy=GenerationType.SEQUENCE)*/
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Integer empId;	
	private String empName;	
	private String city;
	private Integer salary;
	@Column(name="doj")
	private LocalDate dateOfJoining;
	/*@Transient
	private Integer servicePeriod;*/
	
	
	/*public Integer getServicePeriod() {
		return servicePeriod;
	}
	public void setServicePeriod(Integer servicePeriod) {
		this.servicePeriod = servicePeriod;
	}*/
	public Integer getEmpId() {
		return empId;
	}
	public void setEmpId(Integer empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	
		
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city; 
	}
	
	
	public LocalDate getDateOfJoining() {
		return dateOfJoining;
	}
	public void setDateOfJoining(LocalDate dateOfJoining) {
		this.dateOfJoining = dateOfJoining;
	}
	public Integer getSalary() {
		return salary;
	}
	public void setSalary(Integer salary) {
		this.salary = salary;
	}
	
	
	
}
